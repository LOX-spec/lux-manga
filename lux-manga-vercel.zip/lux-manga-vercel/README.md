# لوكس مانجا

نسخة مصدر للموقع جاهزة للربط مع GitHub وVercel. الواجهة مبنية بـ HTML وCSS وJavaScript، ويشغّل Node.js مسارات الروايات وواجهات جلب المصادر. يشمل المشروع رف الروايات التجريبية، القارئ، لوحة نشر الروايات والفصول، وتثبيت تطبيق الويب.

## هيكل المشروع

```text
lux-manga-vercel/
├── README.md
├── .gitignore
├── package.json
├── vercel.json
├── src/
│   ├── index.html                         هيكل الواجهة والتنقل
│   ├── style.css, studio.css, studio.js   التصميم وأقسام المكتبة
│   ├── app.js, collections.js             حالة المكتبة وعرض الأقسام
│   ├── discovery.js, experience.js        الاكتشاف والتوصيات
│   ├── import.js, scanner.js, audit.js     استيراد المصادر وفحصها
│   ├── media.js, source-delete.js         دعم أنواع الأعمال وإدارة المصادر
│   ├── settings.js, features.js          إعدادات وتجربة التطبيق
│   ├── novels-demo.js, novels-view.*      بيانات الروايات التجريبية والرف
│   ├── novel-admin.*                     شاشة النشر وتصميمها
│   ├── novel-publications.js             حفظ الروايات والفصول في المتصفح
│   ├── novel-pages.js                    قوالب الفهرس والقارئ
│   ├── novel-page-runtime.js             ربط القوالب بالبيانات المحلية
│   ├── novel-details*.{js,css}            تصميم الفهرس وأدواته
│   ├── novel-reader.*, sample-reader*    واجهات القراءة وأدواتها
│   ├── install.*, manifest.webmanifest   تثبيت تطبيق الويب
│   ├── sw.js                             التخزين المؤقت والعمل دون اتصال
│   └── *.svg, *.png                      الأغلفة والرسوم والأيقونات
├── api/
│   ├── page.js                           مسارات الصفحة والفهرس والقارئ
│   ├── source.js                         فحص مصدر عام
│   └── image.js                          جلب الصور
├── worker/
│   ├── api.js                            منطق جلب المصادر والصور
│   └── public-fetch.js                   اتصال HTTPS بالمصادر العامة
├── scripts/
│   ├── build.mjs                         تجهيز public-build لـ Vercel
│   ├── build-sample-reader.mjs           إنشاء صفحات الروايات التجريبية
│   └── preview.mjs                       معاينة محلية للواجهة والوظائف
└── android/                              مصدر المشغّل التجريبي وملف APK السابق
```

## التشغيل محليًا

ثبّت Node.js 24 وافتح PowerShell داخل المجلد الذي يحتوي على `package.json` ثم نفّذ:

```powershell
npm run preview
```

افتح [لوكس على جهازك](http://127.0.0.1:4173/). جرّب [رف الروايات](http://127.0.0.1:4173/?view=novels) و[لوحة الإدارة](http://127.0.0.1:4173/?view=admin). يمكنك تنفيذ `node scripts/build.mjs` ثم `node scripts/preview.mjs` إذا كان لديك Node.js فقط.

## رفع الملفات إلى GitHub

1. فك الضغط وافتح PowerShell داخل مجلد `lux-manga-vercel`.
2. أنشئ مستودعًا فارغًا باسم مثل `lux-manga` على GitHub. اترك خيارات إنشاء README وملف التجاهل والترخيص فارغة، فالملفات المطلوبة موجودة في الحزمة.
3. نفّذ الأوامر التالية بعد استبدال `YOUR_USERNAME` باسم حسابك وتعديل اسم المستودع إذا اخترت اسمًا آخر.

```powershell
git init -b main
git add .
git commit -m "Import Lux Manga source"
git remote add origin https://github.com/YOUR_USERNAME/lux-manga.git
git push -u origin main
```

يمكن أن يكون مستودع الشفرة خاصًا وتبقى نسخة الموقع عامة، وفق إعدادات الوصول في Vercel. [دليل GitHub لرفع مشروع محلي](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github).

## ربط المستودع بـ Vercel

1. من لوحة Vercel اختر **Add New → Project**، ثم اربط حساب GitHub إذا طُلب منك.
2. اختر مستودع `lux-manga` واضغط **Import**.
3. اترك **Root Directory** على جذر المستودع. إعداد **Other** وأمر البناء `npm run build` ومجلد المخرجات `public-build` تأتي من `vercel.json`. المشروع يعمل دون متغيرات بيئة.
4. اضغط **Deploy**. بعد نجاح النشر انسخ عنوان الإنتاج من **Domains** وجرّبه في نافذة خاصة قبل مشاركته.
5. أي دفع جديد إلى فرع `main` يُنشئ نسخة إنتاج جديدة على عنوان المشروع نفسه. يمكنك أيضًا ربط نطاق تملكه من **Settings → Domains**.

[ربط مستودع Git بـ Vercel](https://vercel.com/docs/git) · [نطاق الإنتاج](https://vercel.com/docs/domains/working-with-domains).

## ما ينتقل مع الكود

تظهر الروايات التجريبية لكل زائر. ما يُضاف عبر لوحة الإدارة يبقى في `localStorage` للمتصفح والعنوان اللذين استُخدما للنشر، ولذلك يبدأ نطاق Vercel بمكتبة محلية منفصلة. نشر فصول مشتركة بين الزوار يحتاج تخزينًا مشتركًا وحسابات إدارة على الخادم.

يدعم الإصدار المنشور تثبيت تطبيق الويب. يحتوي `android/legacy/` على ملف APK السابق للأرشفة، وهو مرتبط بعنوان الاستضافة القديم. لتوزيع APK يفتح نطاق Vercel، غيّر قيمة `HOME` في مصدر Android وأعد بناء الملف وتوقيعه.

تجلب وظيفتا المصادر والصور عناوين HTTPS العامة التي تتوفر عبر IPv4، ويبلغ حد البيانات لكل استجابة 4 MiB. تعتمد نتيجة الاستيراد على توفر المصدر واستجابته. [حدود Vercel Functions](https://vercel.com/docs/functions/limitations).
