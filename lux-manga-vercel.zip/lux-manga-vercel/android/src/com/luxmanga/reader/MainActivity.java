package com.luxmanga.reader;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
public final class MainActivity extends Activity {
 private static final String HOME="https://lux-manga-library-kfsh.rocks-d-xebec.chatgpt.site/";
 @Override public void onCreate(Bundle saved){super.onCreate(saved);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(30,80,30,50);root.setBackgroundColor(Color.rgb(23,19,17));TextView title=new TextView(this);title.setText("لوكس مانجا");title.setTextColor(Color.rgb(244,234,223));title.setTextSize(32);title.setTypeface(Typeface.DEFAULT_BOLD);title.setGravity(Gravity.CENTER);root.addView(title);TextView note=new TextView(this);note.setText("مانجا · مانهوا · كومكس · روايات\n\nنسخة أندرويد 0.2.0 التجريبية\n\nيفتح لوكس عبر متصفح جهازك للاحتفاظ بجلسة تسجيل الدخول والتخزين الخاصة بالمتصفح. تحتاج اتصالًا للفتح أول مرة. هذه النسخة مشغّل للموقع وليست قارئًا أصليًا مستقلًا.\n");note.setTextColor(Color.rgb(204,185,166));note.setTextSize(17);note.setGravity(Gravity.CENTER);note.setPadding(8,28,8,20);root.addView(note);Button open=new Button(this);open.setText("افتح لوكس مانجا");open.setTextColor(Color.WHITE);open.setBackgroundColor(Color.rgb(199,72,56));open.setPadding(25,18,25,18);root.addView(open,new LinearLayout.LayoutParams(-1,-2));open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){openLux();}});Button install=new Button(this);install.setText("تثبيت تطبيق الويب — للقراءة دون اتصال");root.addView(install,new LinearLayout.LayoutParams(-1,-2));install.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(HOME+"?view=getapp")));}catch(Exception e){Toast.makeText(MainActivity.this,"افتح رابط لوكس في متصفحك",Toast.LENGTH_LONG).show();}}});setContentView(root);if(saved==null)root.postDelayed(new Runnable(){public void run(){openLux();}},300);}
 private void openLux(){try{Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(HOME));intent.addCategory(Intent.CATEGORY_BROWSABLE);Bundle extras=new Bundle();try{Bundle.class.getMethod("putBinder",String.class,android.os.IBinder.class).invoke(extras,"android.support.customtabs.extra.SESSION",null);}catch(Exception ignored){}intent.putExtras(extras);intent.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR",Color.rgb(23,19,17));intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY",1);startActivity(intent);}catch(Exception e){Toast.makeText(this,"تعذر فتح المتصفح. ثبّت Chrome أو افتح رابط لوكس من متصفحك.",Toast.LENGTH_LONG).show();}}
}
