import java.io.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.nio.file.*;
import java.util.*;
import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;
public class SignApk {
 public static void main(String[] args)throws Exception {char[] password=Files.readString(Path.of(args[1])).toCharArray();KeyStore store=KeyStore.getInstance("PKCS12");try(InputStream in=new FileInputStream(args[0])){store.load(in,password);}String alias=store.aliases().nextElement();PrivateKey key=(PrivateKey)store.getKey(alias,password);X509Certificate cert=(X509Certificate)store.getCertificate(alias);ApkSigner.SignerConfig signer=new ApkSigner.SignerConfig.Builder("lux-local-test",key,Collections.singletonList(cert)).build();new ApkSigner.Builder(Collections.singletonList(signer)).setInputApk(new File(args[2])).setOutputApk(new File(args[3])).setMinSdkVersion(23).setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true).setV4SigningEnabled(false).build().sign();ApkVerifier.Result result=new ApkVerifier.Builder(new File(args[3])).setMinCheckedPlatformVersion(23).setMaxCheckedPlatformVersion(35).build().verify();if(!result.isVerified())throw new Exception("Signature verification failed: "+result.getErrors());System.out.println("APK signature verified. v1="+result.isVerifiedUsingV1Scheme()+" v2="+result.isVerifiedUsingV2Scheme()+" v3="+result.isVerifiedUsingV3Scheme());Arrays.fill(password,'\0');}
}
