function renderNovelAdmin() {
  const count = new Intl.NumberFormat('ar');
  const page = document.getElementById('page');
  page.innerHTML = `
    <section class="novel-admin" aria-labelledby="novel-admin-title">
      <header class="novel-admin-intro">
        <div>
          <span class="eyetag" lang="en">LUX TRANSLATOR STUDIO</span>
          <h1 id="novel-admin-title">لوحة إدارة الروايات</h1>
          <p>أضف رواية، ثم انشر فصولها مباشرة في رف الروايات.</p>
        </div>
        <a href="/?view=novels">افتح رف الروايات ←</a>
      </header>
      <p class="novel-admin-storage">يحفظ لوكس ما تنشره في متصفح هذا الجهاز ويعرضه في رفّك هنا.</p>
      <div class="novel-admin-grid">
        <form id="novel-publish" class="novel-admin-panel">
          <header><span class="novel-admin-step">١</span><div><h2>إضافة رواية</h2><p>عرّف القارئ بالعمل قبل نشر فصله الأول.</p></div></header>
          <label>عنوان الرواية<input name="title" required maxlength="160" dir="auto"></label>
          <label>اسم المؤلف<input name="author" required maxlength="120" dir="auto"></label>
          <label>رابط صورة الغلاف<input type="url" name="cover" required maxlength="2048" dir="ltr" placeholder="https://example.com/cover.jpg"></label>
          <label>النبذة<textarea name="synopsis" required maxlength="2400" rows="4" dir="auto"></textarea></label>
          <label>التصنيفات<input name="genres" required maxlength="220" dir="auto" placeholder="فانتازيا، مغامرة"></label>
          <div class="novel-admin-field"><label for="novel-publish-status">حالة الرواية</label>
            <select id="novel-publish-status" name="status"><option>مستمرة</option><option>مكتملة</option></select>
          </div>
          <button type="submit" class="primary">حفظ ونشر الرواية</button>
          <p class="novel-admin-result" role="status"></p>
        </form>
        <form id="chapter-publish" class="novel-admin-panel">
          <header><span class="novel-admin-step">٢</span><div><h2>إضافة فصل</h2><p>اختر الرواية واكتب الفصل أو الصق نصه.</p></div></header>
          <div class="novel-admin-field"><label for="chapter-publish-book">الرواية</label>
            <select id="chapter-publish-book" name="bookId" required></select>
          </div>
          <label>رقم الفصل<input name="number" required inputmode="decimal" dir="ltr" maxlength="16" placeholder="25.1"></label>
          <label>عنوان الفصل<input name="title" required maxlength="180" dir="auto"></label>
          <label>نص الفصل<textarea name="body" required rows="13" dir="auto" aria-describedby="chapter-image-hint"></textarea></label>
          <p id="chapter-image-hint">اترك سطرًا فارغًا بين الفقرات. لإضافة صورة، ضع رابطها المباشر في سطر مستقل، أو استخدم <code dir="ltr">![وصف الصورة](https://example.com/image.jpg)</code>.</p>
          <button type="submit" class="primary">نشر الفصل</button>
          <p class="novel-admin-result" role="status"></p>
        </form>
      </div>
    </section>`;
  const novelForm = page.querySelector('#novel-publish');
  const chapterForm = page.querySelector('#chapter-publish');
  const select = chapterForm.elements.bookId;

  function updateBooks(selected = select.value) {
    const options = LuxNovelPublications.catalogue().map(book =>
      new Option(`${book.title} · عدد الفصول: ${count.format(book.chapters.length)}`, book.id));
    select.replaceChildren(new Option('اختر رواية', ''), ...options);
    select.value = options.some(option => option.value === selected) ? selected : '';
  }

  function bind(form, publish) {
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const result = form.querySelector('[role="status"]');
      const button = form.querySelector('[type="submit"]');
      button.disabled = true;
      result.classList.remove('is-error');
      try {
        const { message, href, label } = await publish(Object.fromEntries(new FormData(form)));
        const link = document.createElement('a');
        link.href = href;
        link.textContent = label;
        result.replaceChildren(message + ' ', link);
      } catch (error) {
        result.classList.add('is-error');
        result.textContent = error.message;
      } finally {
        button.disabled = false;
      }
    });
  }

  bind(novelForm, fields => {
    const book = LuxNovelPublications.publishNovel(fields);
    novelForm.reset();
    updateBooks(book.id);
    return { message: 'حُفظت الرواية وأضيفت إلى الرف.', href: LuxNovelPages.detailsUrl(book.id), label: 'عرض الرواية' };
  });
  bind(chapterForm, async fields => {
    const chapter = await LuxNovelPublications.publishChapter(fields);
    chapterForm.reset();
    updateBooks(chapter.bookId);
    return { message: 'نُشر الفصل وأُضيف إلى الفهرس.', href: LuxNovelPages.chapterUrl(chapter.bookId, chapter.number), label: 'قراءة الفصل' };
  });
  updateBooks();
  page.querySelector('.novel-admin').addEventListener('novel-catalog-change', () => updateBooks());
}

function refreshNovelShelf() {
  if (view === 'novels') {
    const shelf = document.getElementById('novel-local-shelf');
    if (shelf) shelf.outerHTML = renderNovelSampleShelf();
  }
}

window.addEventListener('storage', event => {
  if (!LuxNovelPublications.changed(event)) return;
  refreshNovelShelf();
  document.querySelector('.novel-admin')?.dispatchEvent(new Event('novel-catalog-change'));
});
window.addEventListener('pageshow', event => {
  if (!event.persisted) return;
  refreshNovelShelf();
  document.querySelector('.novel-admin')?.dispatchEvent(new Event('novel-catalog-change'));
});
