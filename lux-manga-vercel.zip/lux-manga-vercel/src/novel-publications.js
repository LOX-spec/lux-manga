const LuxNovelPublications = (() => {
  const prefix = 'lux-novel-studio:v1:';
  const bookPrefix = prefix + 'book:';
  const chapterPrefix = prefix + 'chapter:';

  function imageUrl(value) {
    try {
      const url = new URL(value);
      if (['https:', 'http:'].includes(url.protocol) && !url.username && !url.password) return url.href;
    } catch {}
    return '';
  }

  function chapterNumber(value) {
    const normalized = String(value).trim()
      .replace(/[٠-٩۰-۹]/g, digit => String(digit.charCodeAt(0) & 15))
      .replace('٫', '.');
    if (!/^\d{1,9}(?:\.\d{1,6})?$/.test(normalized)) return null;
    const number = Number(normalized);
    return number > 0 ? number : null;
  }

  function records(keyPrefix) {
    const items = [];
    try {
      for (let index = 0; index < localStorage.length; index++) {
        const key = localStorage.key(index);
        if (!key?.startsWith(keyPrefix)) continue;
        try {
          const record = JSON.parse(localStorage.getItem(key));
          if (record) items.push(record);
        } catch {
          // An unreadable record should not hide the rest of the catalog.
        }
      }
    } catch {
      // The bundled novels remain readable when storage is disabled.
    }
    return items;
  }

  function catalogue() {
    const chaptersByBook = new Map();
    for (const chapter of records(chapterPrefix)) {
      if (!chaptersByBook.has(chapter.bookId)) chaptersByBook.set(chapter.bookId, []);
      chaptersByBook.get(chapter.bookId).push(chapter);
    }
    const published = records(bookPrefix).sort((a, b) => b.publishedAt - a.publishedAt);
    return [...published, ...NOVELS_DATA].map(book => ({
      ...book,
      chapters: [...book.chapters, ...(chaptersByBook.get(String(book.id)) || [])]
        .sort((a, b) => a.number - b.number)
    }));
  }

  function write(key, record) {
    try {
      localStorage.setItem(key, JSON.stringify(record));
    } catch {
      throw new Error('تعذّر النشر. تحقّق من مساحة التخزين وإذن حفظ بيانات الموقع في المتصفح.');
    }
  }

  function publishNovel({ title, author, cover, synopsis, genres, status }) {
    const book = {
      id: 'studio-' + crypto.randomUUID(),
      title: title.trim(), author: author.trim(), cover: imageUrl(cover.trim()),
      synopsis: synopsis.trim(),
      genres: [...new Set(genres.split(/[،,\n]/).map(tag => tag.trim()).filter(Boolean))],
      status, chapters: [], publishedAt: Date.now()
    };
    if (!book.title || !book.author || !book.synopsis || !book.genres.length) {
      throw new Error('أدخل العنوان والمؤلف والنبذة وتصنيفًا واحدًا على الأقل.');
    }
    if (!book.cover) throw new Error('أدخل رابط صورة غلاف صالحًا يبدأ بـ HTTPS أو HTTP.');
    if (!['مستمرة', 'مكتملة'].includes(book.status)) throw new Error('اختر حالة الرواية.');
    write(bookPrefix + book.id, book);
    return book;
  }

  function chapterContent(body) {
    const content = [];
    let lines = [];
    function flush() {
      if (!lines.length) return;
      content.push({ text: lines.join('\n') });
      lines = [];
    }
    for (const raw of body.split(/\r\n?|\n/)) {
      const line = raw.trim();
      const markdown = /^!\[([^\]]*)\]\((.+)\)$/.exec(line);
      const direct = /^https?:\/\/\S+$/i.test(line);
      const url = imageUrl(markdown?.[2] ?? (direct ? line : ''));
      if (markdown && !url) throw new Error('أحد روابط الصور في الفصل غير صالح.');
      if (url) {
        flush();
        content.push({ image: url, alt: markdown?.[1] || 'صورة من الفصل' });
      } else if (line) {
        lines.push(line);
      } else {
        flush();
      }
    }
    flush();
    return content;
  }

  function publishChapter({ bookId, number: inputNumber, title, body }) {
    const number = chapterNumber(inputNumber);
    if (number === null) throw new Error('أدخل رقم فصل موجبًا، مثل 1 أو 25.1.');
    const content = chapterContent(body);
    if (!title.trim() || !content.length) throw new Error('أدخل عنوان الفصل ومحتواه.');
    const chapter = { bookId, number, title: title.trim(), content };
    const key = chapterPrefix + bookId + ':' + number;
    function saveChapter() {
      const book = catalogue().find(item => String(item.id) === bookId);
      if (!book) throw new Error('اختر الرواية التي تريد النشر فيها.');
      if (book.chapters.some(item => item.number === number)) {
        throw new Error('رقم الفصل مستخدم بالفعل في هذه الرواية.');
      }
      write(key, chapter);
      return chapter;
    }
    return navigator.locks ? navigator.locks.request(key, saveChapter) : saveChapter();
  }

  return { catalogue, chapterNumber, publishNovel, publishChapter,
    changed: event => event.key === null || event.key.startsWith(prefix) };
})();
