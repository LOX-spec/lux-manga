const SHELL='lux-shell-v26',PAGES='lux-pages-v1',COVERS='lux-novel-covers-v1';
const SAMPLE_PAGE_URLS = [];
const SAMPLE_COVER_URLS = [];
const COVER_FALLBACK='/novel-cover-fallback.svg';
const FILES=['/',COVER_FALLBACK,...SAMPLE_COVER_URLS,'/novels-demo.js','/novels-view.js','/novels-view.css','/novel-reader.js','/novel-reader.css','/style.css','/studio.css','/install.css','/app.js','/import.js','/audit.js','/settings.js','/features.js','/experience.js','/media.js','/discovery.js','/scanner.js','/source-delete.js','/collections.js','/studio.js','/install.js','/manifest.webmanifest','/icon-192.png','/icon-512.png'];
const NOVEL_ASSETS = ['/novel-admin.js', '/novel-admin.css', '/novel-publications.js', '/novel-pages.js',
  '/novel-page-runtime.js', '/novel-details-controls.js', '/sample-reader-controls.js'];
const NOVEL_SHELLS = ['/?view=novel', '/?view=reader'];
// Cache an entire matching shell. Login pages must never replace the application.
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(SHELL);
  for (const path of new Set([...FILES, ...NOVEL_ASSETS, ...NOVEL_SHELLS, ...SAMPLE_PAGE_URLS])) {
    const response = await fetch(new Request(path, { cache: 'reload' }));
    if (!response.ok || response.redirected) throw Error('App shell unavailable');
    if (path === '/' && !(await response.clone().text()).includes('class="studio"')) {
      throw Error('Authentication required');
    }
    if (path.startsWith('/?view=reader&') && !(await response.clone().text()).includes('id="reader-content"')) {
      throw Error('Sample reader page unavailable');
    }
    if (path.startsWith('/?view=novel&') && !(await response.clone().text()).includes('id="novel-details"')) {
      throw Error('Sample novel details unavailable');
    }
    if (NOVEL_SHELLS.includes(path) && !(await response.clone().text()).includes('/novel-page-runtime.js')) {
      throw Error('Novel page shell unavailable');
    }
    await cache.put(path, response);
  }
  await self.skipWaiting();
})()));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('lux-shell-')&&key!==SHELL)await caches.delete(key);await self.clients.claim()})()));
async function novelCoverResponse(request) {
  const covers = await caches.open(COVERS).catch(() => null);
  const cached = await covers?.match(request).catch(() => null);
  if (cached) return cached;

  try {
    const response = await fetch(request, { signal: AbortSignal.timeout(4500) });
    if (response.ok && /^image\//i.test(response.headers.get('Content-Type') || '')) {
      const size = Number(response.headers.get('Content-Length'));
      if (covers && size > 0 && size <= 1536 * 1024) {
        try {
          await covers.put(request, response.clone());
          const entries = await covers.keys();
          await Promise.all(entries.slice(0, Math.max(0, entries.length - 48)).map(entry => covers.delete(entry)));
        } catch {
          // A full cache must not prevent display of a valid cover.
        }
      }
      return response;
    }
  } catch {
    // Offline, timed out, or source unavailable. Use the bundled artwork.
  }
  const shell = await caches.open(SHELL);
  return await shell.match(COVER_FALLBACK) || Response.error();
}

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || event.request.method !== 'GET') return;
  const novelView = novelPageView(url);
  if (novelView) {
    const sampleKey = samplePagePath(url);
    const key = SAMPLE_PAGE_URLS.includes(sampleKey) ? sampleKey : '/?view=' + novelView;
    event.respondWith((async () => {
      const cache = await caches.open(SHELL);
      return await cache.match(key) || fetch(event.request);
    })());
    return;
  }
  if (url.pathname === '/api/image') {
    if (url.searchParams.get('kind') === 'cover') {
      event.respondWith(novelCoverResponse(event.request));
    } else {
      event.respondWith((async () => {
        const cache = await caches.open(PAGES);
        return await cache.match(event.request) || fetch(event.request);
      })());
    }
    return;
  }
  if (FILES.includes(url.pathname) || NOVEL_ASSETS.includes(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(SHELL);
      return await cache.match(url.pathname) || fetch(event.request);
    })());
  }
});
