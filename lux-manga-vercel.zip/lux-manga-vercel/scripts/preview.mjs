import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { Readable } from 'node:stream';
import { GET as page, HEAD as pageHead } from '../api/page.js';
import { POST as source } from '../api/source.js';
import { GET as image } from '../api/image.js';

const port = Number(process.env.PORT || 4173);
const origin = 'http://127.0.0.1:' + port;
const root = resolve('public-build');
const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json'
};

async function handle(request) {
  const { pathname } = new URL(request.url);
  if (pathname === '/' || pathname === '/api/page') {
    if (request.method === 'GET') return page(request);
    if (request.method === 'HEAD') return pageHead(request);
    return new Response('Method not allowed', { status: 405 });
  }
  if (pathname === '/api/source') return source(request);
  if (pathname === '/api/image') return image(request);
  if (!['GET', 'HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405 });
  const file = resolve(root, '.' + decodeURIComponent(pathname));
  const info = file.startsWith(root + sep) && await stat(file).catch(() => null);
  if (!info?.isFile()) return new Response('Not found', { status: 404 });
  const body = request.method === 'HEAD' ? null : Readable.toWeb(createReadStream(file));
  return new Response(body, { headers: {
    'Content-Type': contentTypes[extname(file)] || 'application/octet-stream',
    'Cache-Control': 'no-cache'
  } });
}

createServer(async (incoming, outgoing) => {
  try {
    const method = incoming.method;
    const request = new Request(origin + incoming.url, {
      method, headers: incoming.headers,
      ...(['GET', 'HEAD'].includes(method) ? {} : { body: Readable.toWeb(incoming), duplex: 'half' })
    });
    const response = await handle(request);
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    if (response.body) Readable.fromWeb(response.body).pipe(outgoing);
    else outgoing.end();
  } catch (error) {
    console.error(error);
    if (!outgoing.headersSent) outgoing.writeHead(500);
    outgoing.end('Preview request failed');
  }
}).listen(port, '127.0.0.1', () => console.log('Lux: ' + origin));
