import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { buildSamplePages, novelPageView, samplePagePath } from './build-sample-reader.mjs';

const output = 'public-build';
const { pages, coverAssets } = buildSamplePages();
const files = readdirSync('src', { withFileTypes: true }).filter(entry => entry.isFile());
const fingerprint = createHash('sha256');
for (const { name } of files.sort((a, b) => a.name.localeCompare(b.name))) {
  fingerprint.update(name).update(readFileSync('src/' + name));
}
fingerprint.update(JSON.stringify(pages));
mkdirSync(output, { recursive: true });
for (const { name } of files) {
  if (name === 'index.html' || name === 'sw.js') continue;
  copyFileSync('src/' + name, output + '/' + name);
}
// The root is served by api/page.js so chapter links retain their query string.
const serviceWorker = readFileSync('src/sw.js', 'utf8')
  .replace(/lux-shell-v\d+/, 'lux-shell-vercel-' + fingerprint.digest('hex').slice(0, 12))
  .replace('const SAMPLE_PAGE_URLS = [];',
    `const SAMPLE_PAGE_URLS = ${JSON.stringify(Object.keys(pages))};\n${samplePagePath}\n${novelPageView}`)
  .replace('const SAMPLE_COVER_URLS = [];',
    `const SAMPLE_COVER_URLS = ${JSON.stringify(Object.keys(coverAssets))};`);
writeFileSync(output + '/sw.js', serviceWorker);
console.log('Vercel public assets built in ' + output);
